# Reverso CLI

CLI do agente investigativo Reverso — OSINT com LLM. Processa documentos, gera entendimento e conduz investigações com leads, allegations e findings rastreáveis.

## Instalação

```bash
# npm
npm install -g @reverso-agent/cli

# pnpm
pnpm add -g @reverso-agent/cli
```

Requisitos: Node.js >= 18.

Verificar:

```bash
reverso --version
reverso --help
```

## Configuração

É obrigatória uma chave de API do OpenRouter. Use uma das opções abaixo (em ordem de prioridade):

**Opção A — Variável de ambiente (recomendado)**

```bash
export OPENROUTER_API_KEY=sk-...
# ou adicione ao ~/.zshrc / ~/.bashrc
```

**Opção B — Arquivo global**

```bash
mkdir -p ~/.reverso
echo "OPENROUTER_API_KEY=sk-..." > ~/.reverso/.env
```

**Opção C — Por projeto**

Crie um arquivo `.env` na pasta da investigação com `OPENROUTER_API_KEY=sk-...`.

Modelo padrão: `google/gemini-2.5-flash` (alterável via `--model` onde disponível).

## Primeiros passos

Fluxo recomendado numa pasta de investigação:

1. **init** — Lê previews em `source/.artifacts`, gera entendimento inicial e cria `agent.md`.
2. **agent-setup** — Ajusta instruções do agente (ex.: foco em pessoa ou tema).
3. **dig** — Encontra possíveis leads a partir dos previews (top 3 sugestões, comparação com leads existentes).
4. **create-lead** — Registra um lead com Inquiry Plan em `investigation/leads`.
5. **inquiry** — Executa a investigação do lead e gera allegations/findings e conclusão.

O CLI detecta automaticamente a pasta de investigação (presença de `source/` ou `investigation/` a partir do diretório atual). Para forçar um caminho: `reverso --filesystem /caminho/para/root <comando>`.

### Exemplo completo

```bash
mkdir minha-investigacao && cd minha-investigacao
mkdir source
# Copie PDFs para source/

reverso doc-process process-all    # processa PDFs e gera previews
reverso init                       # gera entendimento
reverso agent-setup --text "Foco na pessoa X"
reverso dig                        # encontra leads
reverso create-lead --idea "cartel combinacao"
reverso inquiry --lead cartel-combinacao
```

## Comandos

- **reverso init** — Entendimento inicial a partir dos previews. Saída: `agent.md`.
- **reverso agent-setup** — Atualiza `agent.md` com novas instruções (`--text "..."`).
- **reverso dig** — Deep-dive nos previews, sugere leads. Saída: relatório em `reports/dig-<timestamp>.md`.
- **reverso create-lead** — Cria lead com Inquiry Plan (`--idea "..."` opcional). Saída: `investigation/leads/lead-<slug>.md`.
- **reverso inquiry** — Executa a investigação de um lead. Saída: allegations, findings e conclusão no lead.
- **reverso doc-process** — Processamento de documentos. Subcomandos: `process-all`, `queue-status`, `queue-clear`, `rerun`, `watch`. Use `reverso doc-process --help` para detalhes.

Flags globais: `--filesystem <path>`, `--feedback plain|compact|visual` (padrão: visual). Use `reverso <comando> --help` para opções de cada comando.

## Saídas esperadas

Estrutura típica após o fluxo (relativa ao root da investigação):

- **init / agent-setup**: `agent.md`
- **dig**: `reports/dig-<timestamp>.md`
- **create-lead**: `investigation/leads/lead-<slug>.md`
- **inquiry**: `investigation/allegations/*.md`, `investigation/findings/*.md`, e conclusão atualizada no lead

## Publicação e atualização de versão

Pacote *scoped* (`@reverso-agent/cli`). Para publicar no npm com 2FA ativada é preciso informar o código OTP quando o npm pedir.

Guia completo (login, 2FA/OTP, erros comuns, CI): **[PUBLISH-NPM.md](./PUBLISH-NPM.md)**.

Resumo:

```bash
cd lab/agent-cli
pnpm typecheck
pnpm build
npm pack                              # gera .tgz para teste local
npm install -g ./reverso-agent-cli-*.tgz    # teste de instalação global
# Se OK:
npm version patch                     # 0.2.4 → 0.2.5 (ou minor/major)
npm publish --access public           # informe o OTP quando solicitado
```

Teste em pasta fora do repositório antes de publicar (ex.: `mkdir /tmp/test-reverso && cd /tmp/test-reverso && reverso --help`).
